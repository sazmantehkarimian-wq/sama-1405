# SAMA MASTER RULEBOOK — منطق جامع و قوانین نهایی سامانه

**پروژه:** سامانه املاک سازمان فرهنگی هنری شهرداری تهران — SAMA  
**نوع سند:** قانون اساسی کسب‌وکار، منطق داده، قواعد فرآیند، کنترل کیفیت، گزارش، اسناد، کاربران و مرزهای سامانه  
**وضعیت:** `FINAL FROZEN — PRE HIGH-FIDELITY UI`  
**هدف:** ایجاد یک مرجع واحد و دقیق برای فهم «SAMA چیست، چه می‌کند و چه کارهایی حق ندارد انجام دهد» قبل از تولید Prompt و شروع کدنویسی.

> این سند منطق تثبیت‌شده ۱۶ MD تخصصی را یکپارچه می‌کند. جزئیات Field-level و Layout-level هر Domain در MD تخصصی همان حوزه باقی می‌ماند. هیچ AI، Developer یا Codex مجاز نیست برای پرکردن سکوت یا ابهام، Rule جدید اختراع کند.

---

# 0. سلسله‌مراتب مرجع

## GOV-001 — Authority

مرجع فعلی پروژه:

```text
1) تصمیم صریح و جدید Owner که در FINAL FROZEN ثبت شده
2) این SAMA MASTER RULEBOOK
3) MD تخصصی FINAL FROZEN همان Domain
4) Golden Master / Field Registry رسمی
5) Prototype / Build قدیمی فقط برای Regression و تجربه
```

اگر بین این سند و یک MD تخصصی تناقض واقعی کشف شد:

```text
STOP
→ REPORT CONFLICT
→ CHANGE REQUEST
→ OWNER REVIEW
→ APPROVED PATCH
→ RE-FREEZE
```

هیچ مجری حق حل سلیقه‌ای تعارض را ندارد.

## GOV-002 — No Guess

حدس در موارد زیر ممنوع است:

- داده؛
- مبلغ؛
- تاریخ؛
- شناسه؛
- وضعیت؛
- ارتباط Entityها؛
- نتیجه مزایده؛
- Rule؛
- متن حقوقی؛
- Priority میان دستورات؛
- مقدار Configuration.

داده ناقص باید به‌صورت ناقص/نیازمند بررسی نمایش داده شود، نه اینکه با داده ساختگی تکمیل شود.

## GOV-003 — Change Control

هر Rule یا تصمیم FROZEN فقط از مسیر:

```text
FROZEN
→ CHANGE REQUEST
→ REVIEW
→ OWNER APPROVAL
→ UPDATED FROZEN
```

تغییر می‌کند.

## GOV-004 — No silent reinterpretation

تغییر UI، Refactor، انتخاب تکنولوژی یا بهینه‌سازی Performance حق تغییر Business Meaning را ندارد.

## GOV-005 — Rule Registry

قواعد قابل‌تنظیم باید:

- شناسه؛
- نسخه؛
- تاریخ اثر؛
- مقدار قبلی؛
- مقدار جدید؛
- کاربر؛
- علت؛
- Audit

داشته باشند.

Rule جدید نباید به‌صورت Hard-code پنهان وارد شود.

---

# 1. Baseline عملیاتی و دامنه پروژه

## DATA-001 — Zero-data

نسخه جدید SAMA با Baseline زیر ساخته می‌شود:

```text
Initial Operational Data = 0
Sample Production Data = 0
Automatic Legacy Import = 0
Automatic Excel Migration = 0
```

کاربر داده عملیاتی را از طریق UI رسمی سامانه وارد می‌کند.

فایل‌ها و Buildهای قبلی فقط منبع تجربه، کشف خطا و Regression هستند.

## DATA-002 — Import آینده

اگر در آینده Import لازم شود:

- باید Change Request مستقل داشته باشد؛
- Mapping رسمی داشته باشد؛
- Validation داشته باشد؛
- Audit/Lineage داشته باشد؛
- Rollback و Acceptance Gate داشته باشد؛
- بدون این موارد Production Import ممنوع است.

## DATA-003 — Single Operational Source

پس از ثبت در SAMA، Database عملیاتی سامانه منبع رسمی وضعیت جاری است.

## DATA-004 — No hidden shadow data

Excel، فایل محلی یا داده پنهان نباید بدون نمایش در UI و Audit روی KPI، Report یا Rule Engine اثر بگذارد.

---

# 2. اصول عمومی داده

## DATA-010 — Entity ownership

هر داده فقط در Entity اصلی خودش ثبت می‌شود و در پرونده‌های دیگر به‌صورت Read Model/Link نمایش داده می‌شود.

Duplicate Business Data Entry ممنوع است.

## DATA-011 — History preservation

سوابق تاریخی overwrite نمی‌شوند مگر در اصلاح موردی یک داده اشتباه، آن هم با Audit.

## DATA-012 — Physical delete

برای رکوردهای اصلی کسب‌وکار:

```text
Physical Delete = PROHIBITED
```

ابطال، لغو، غیرفعال‌سازی یا Correction با Status/History انجام می‌شود.

## DATA-013 — Empty ≠ Zero ≠ Unknown

سه وضعیت مستقل هستند:

```text
NULL / Empty
0
Unknown / Needs Review
```

## DATA-014 — Timestamps

هر تغییر مهم حداقل:

- User
- Date
- Time
- Action
- Entity
- Record ID
- Old Value
- New Value
- Reason/Context در صورت نیاز

دارد.

## DATA-015 — Currency

مبنای ذخیره و محاسبات مبالغ رسمی SAMA:

```text
IRR / ریال
```

نمایش تومان فقط در جایی که به‌صورت صریح برای کمک کاربر لازم باشد و نباید مقدار رسمی را عوض کند.

---

# 3. کاربران، Authentication و Audit

## AUTH-001 — کاربران عملیاتی

پنج کاربر نام‌دار عملیاتی وجود دارند:

- اکبر قربانی؛
- اکبر مجیدی؛
- مجید عبداللهی؛
- زهره محمدی؛
- سید محمد کریمیان.

Usernameها و Bootstrap Passwordهای مصوب فقط در MD «معماری اطلاعات، Sitemap، Navigation و کاربران» نگهداری می‌شوند و در این Master تکرار نمی‌شوند.

## AUTH-002 — دسترسی برابر

```text
Five Named Operational Users = Equal Full Operational Access
```

Role عملیاتی جداگانه در Baseline فعلی وجود ندارد.

عنوان شغلی کاربر باعث محدودشدن Domainها نمی‌شود.

## AUTH-003 — Admin

یک حساب فنی مستقل `admin` وجود دارد.

قاعده:

- مدیریت کاربران؛
- Reset Password؛
- فعال/غیرفعال‌سازی حساب؛
- مشاهده وضعیت اولین ورود؛
- دسترسی کامل سامانه؛
- استفاده روزمره عملیاتی توصیه نمی‌شود.

Credential ثابت Admin در MD تخصصی کاربران نگهداری می‌شود.

## AUTH-004 — First Login

پنج کاربر عملیاتی:

```text
Initial Login
→ Mandatory Password Change
→ Main Application
```

تا قبل از تغییر Password اولیه، Dashboard اصلی باز نمی‌شود.

## AUTH-005 — Forgot Password

بازیابی عمومی وجود ندارد:

- Email Recovery = No
- SMS Recovery = No
- Security Question = No
- Public Forgot Password = No

فراموشی رمز فقط از مسیر Admin Reset می‌شود.

## AUTH-006 — Password storage

Password Plain Text در Database یا Audit ممنوع است.

```text
Password Storage = HASHED
```

## AUTH-007 — Audit identity

هر عملیات Business به User نام‌دار متصل است.

Admin action نیز Audit می‌شود.

## AUTH-008 — LAN security philosophy

امنیت متناسب با LAN و تیم کوچک است.

الزامات:

- Login؛
- Session؛
- Password Hash؛
- Named User؛
- Admin restriction؛
- Audit؛
- Input validation.

خارج از Scope فعلی:

- MFA؛
- SSO؛
- OTP؛
- Email/SMS recovery؛
- Complex RBAC؛
- Device Certificate.

---

# 4. معماری اطلاعات و Navigation

## NAV-001 — الگوی اصلی

```text
List
→ Profile
→ Domain Tabs
```

## NAV-002 — Main Sitemap

Domainهای اصلی:

1. Dashboard
2. فضاهای تجاری
3. املاک مادر
4. قراردادها
5. بهره‌برداران
6. کارشناسی
7. کمیسیون معاملات
8. مزایده
9. انشعابات و مصرف
10. گزارش‌ها و تحلیل مدیریتی
11. تنظیمات
12. حساب کاربری
13. Admin/User Management فقط برای admin

## NAV-003 — Space dossier

پرونده کد فضا نقطه اتصال خواندنی Domainهای مرتبط است:

- خلاصه؛
- مشخصات؛
- بهره‌بردار؛
- قرارداد؛
- کارشناسی؛
- مزایده؛
- کمیسیون؛
- حق‌الزحمه؛
- انشعابات؛
- اسناد؛
- تاریخچه/Audit.

داده در این تب‌ها Duplicate نمی‌شود.

## NAV-004 — Scope preservation

Filter، Search، Scope و Sort در رفت‌وبرگشت List/Profile باید تا حد ممکن حفظ شوند.

## NAV-005 — Deep link

Deep Link باید Context را بازسازی کند، بدون افشای داده حساس در URL.

## NAV-006 — No dead ends

هر Action/KPI/Alert باید مقصد واقعی داشته باشد.

```text
Dead-end Page = 0
Hidden Required Action = 0
Duplicate Business Data Entry = 0
```

---

# 5. ParentProperty — املاک مادر

## PP-001 — Entity مستقل

`ParentProperty` و `CommercialSpace` دو Entity مستقل و هم‌سطح هستند.

## PP-002 — رابطه اختیاری

```text
ParentProperty 0..N ↔ 0..N CommercialSpace
```

این رابطه:

- اختیاری؛
- تطبیقی؛
- گزارشی؛

است و Dependency عملیاتی ایجاد نمی‌کند.

## PP-003 — No automatic transfer

Link ملک مادر/فضا باعث انتقال خودکار این داده‌ها نمی‌شود:

- قرارداد؛
- بهره‌بردار؛
- کارشناسی؛
- مزایده؛
- وضعیت حقوقی؛
- مالکیت؛
- بهره‌برداری.

## PP-004 — Parent code

هر ملک مادر کد یکتای ثابت دارد.

فرمت نمونه:

```text
MP-000001
```

کد پس از ایجاد تغییر نمی‌کند.

## PP-005 — No appraisal / auction on parent

روی ParentProperty:

- کارشناسی فضای تجاری نداریم؛
- مبلغ کارشناسی فضای تجاری نداریم؛
- Eligibility مزایده نداریم؛
- قرارداد تجاری به ParentProperty منتقل نمی‌شود.

## PP-006 — مالکیت

مالک، سند مالکیت، مالک‌های متعدد و تاریخچه مالکیت ساختاریافته و غیرمخرب نگهداری می‌شوند.

## PP-007 — بهره‌برداری

این مفاهیم مستقل‌اند:

- مالک؛
- واحد در اختیارگیرنده؛
- بهره‌بردار؛
- طرف قرارداد.

نباید یکی به‌جای دیگری استفاده شود.

## PP-008 — Utilities summary

در پرونده ParentProperty فقط Presence/Type انشعاب نمایش داده می‌شود.

جزئیات تخصصی مصرف در Utility Module است.

## PP-009 — Zero-data

هیچ رکورد ParentProperty از Excel قبلی Preload نمی‌شود.

---

# 6. CommercialSpace — فضاهای تجاری

## SPACE-001 — Entity واحد

در Backend فقط یک Entity `CommercialSpace` وجود دارد.

در UI دو View مستقل:

```text
Active
Out-of-Cycle
```

وجود دارد.

## SPACE-002 — عدم اختلاط روزمره

فضاهای فعال و از دور خارج‌شده در فهرست عادی با هم مخلوط نمی‌شوند.

## SPACE-003 — Lifecycle

Lifecycle دوطرفه و Auditدار است:

```text
ACTIVE ⇄ OUT_OF_CYCLE
```

هر Transition باید:

- دلیل؛
- تاریخ؛
- مرجع در صورت نیاز؛
- User؛
- Audit

داشته باشد.

## SPACE-004 — SpaceCode

کد فضا:

- اجباری؛
- یکتا؛
- Primary Business Identifier؛
- غیرقابل تغییر؛
- غیرقابل استفاده مجدد.

## SPACE-005 — Parent link

ارتباط با ParentProperty اختیاری است و نبود آن مانع ثبت/عملیات نیست.

## SPACE-006 — Current beneficiary display

در فهرست فعال:

- نام بهره‌بردار جاری؛
- یا `فاقد بهره‌بردار`.

در Out-of-Cycle در صورت وجود، آخرین بهره‌بردار قابل نمایش است.

## SPACE-007 — No photo/gallery

```text
CommercialSpace Photo Field = NONE
CommercialSpace Gallery = NONE
```

عکس فضای تجاری جزو Data Model نیست.

## SPACE-008 — Completeness

پرونده می‌تواند ناقص باشد؛ Completeness توسط سیستم و Context-aware محاسبه می‌شود.

عدم تکمیل نباید با حدس جبران شود.

---

# 7. Beneficiary — بهره‌بردار

## BEN-001 — Entity مستقل

Beneficiary از Contract و CommercialSpace مستقل است.

## BEN-002 — Code

کد داخلی Beneficiary یکتا و ثابت است.

## BEN-003 — حقیقی/حقوقی

دو نوع اصلی:

```text
REAL_PERSON
LEGAL_PERSON
```

فیلدها و کنترل Duplicate متناسب با نوع هستند.

## BEN-004 — Duplicate check

برای حقیقی و حقوقی از شناسه‌های رسمی مناسب جهت Duplicate Detection استفاده می‌شود.

کد داخلی SAMA Primary Identifier باقی می‌ماند.

## BEN-005 — Contract cardinality

هر Contract دقیقاً یک Beneficiary دارد.

Beneficiary می‌تواند در طول زمان چند Contract/Space داشته باشد.

## BEN-006 — No contract beneficiary

وجود Beneficiary بدون Contract مجاز است.

```text
No Beneficiary ≠ No Contract
```

این دو Status مستقل‌اند.

## BEN-007 — History

تغییر بهره‌بردار سابقه قبلی را حذف نمی‌کند.

---

# 8. Contract — قرارداد

## CON-001 — Entity مستقل

هر Contract:

```text
1 CommercialSpace
1 Beneficiary
```

دارد.

## CON-002 — No overlapping current contracts

برای یک Space در یک زمان بیش از یک Current Contract معتبر مجاز نیست.

Overlap باید Block/Review شود.

## CON-003 — Sequential contracts

یک Space می‌تواند در طول زمان چند Contract متوالی داشته باشد.

## CON-004 — No extension workflow

در SAMA Entity/Workflow مستقل «تمدید قرارداد» وجود ندارد.

ادامه رابطه قراردادی:

```text
New Contract Record
```

است.

## CON-005 — Contract dates

تاریخ‌های اصلی:

- تاریخ شروع قرارداد؛
- تاریخ پایان قرارداد.

Duration از این دو محاسبه می‌شود و ورودی مستقل قابل اتکا نیست.

## CON-006 — Long term

```text
LongTerm = DurationDays > 365
```

این Flag اطلاعاتی/گزارشی است.

Long-term بودن به‌خودی‌خود مانع Eligibility مزایده نیست.

## CON-007 — Temporal vs legal status

وضعیت زمانی Contract از وضعیت حقوقی آن مستقل است.

## CON-008 — Finance section

اطلاعات مالی Contract Section مستقل از اطلاعات عمومی دارد.

## CON-009 — Transaction level basis

وقتی Current Contract وجود دارد، مبلغ Current Contract مبنای جاری تعیین Transaction Level است.

## CON-010 — Auction source

Contract حاصل از Auction می‌تواند Source AuctionLot را نگهداری کند.

---

# 9. Expert & Appraisal — کارشناسان و کارشناسی

## APP-001 — دو Entity مستقل

```text
Expert = Person
Appraisal = Process/Record
```

## APP-002 — Relation

هر Appraisal:

```text
1 CommercialSpace
1 Expert
```

دارد.

یک Space در طول زمان می‌تواند تاریخچه Appraisal داشته باشد.

## APP-003 — Current appraisal

در هر لحظه فقط یک Appraisal می‌تواند Current/Reference باشد.

وجود دو Current Appraisal ناسازگاری داده است و باید Block/Alert شود.

## APP-004 — Historical preservation

ثبت کارشناسی جدید واقعی، کارشناسی قبلی را حذف نمی‌کند.

## APP-005 — Correction

دو مفهوم جدا:

1. اصلاح موردی داده اشتباه؛
2. کارشناسی جدید واقعی.

اصلاح موردی باید Audit داشته باشد و History غیرضروری نسازد.

## APP-006 — Appraisal date

تاریخ خود کارشناسی از:

- تاریخ ابلاغ؛
- تاریخ جواب؛
- تاریخ ثبت در SAMA

مستقل است.

## APP-007 — Auction validity

```text
Auction Validity = 6 Jalali calendar months from AppraisalDate
```

تاریخ متناظر شش ماه بعد آخرین روز معتبر است؛ از روز بعد Expired.

## APP-008 — File optional

فایل کارشناسی اجباری نیست.

وجود داده ساختاریافته کافی است.

## APP-009 — Validity scope

انقضای کارشناسی فقط مانع آمادگی/برگزاری مزایده است.

انقضا Current Contract را بی‌اعتبار نمی‌کند.

## APP-010 — No current contract

در نبود Current Contract، آخرین Appraisal معتبر می‌تواند مبنای مبلغ و Transaction Level باشد.

## APP-011 — With current contract

با Current Contract:

- Contract Amount مبنای Transaction Level؛
- Appraisal Validity برای Auction Readiness جداگانه کنترل می‌شود.

---

# 10. Transaction Level — سطح معاملات

## LVL-001 — Levels

سه سطح:

```text
جزء
متوسط
عمده
```

## LVL-002 — Source

```text
Has Current Contract
→ Current Contract Amount

No Current Contract
→ Latest Valid Appraisal Amount
```

## LVL-003 — Annual versioning

Thresholdها سالانه و Versioned هستند و Hard-code نمی‌شوند.

## LVL-004 — نمونه سال 1405

مبنای ذخیره رسمی: ریال.

```text
جزء:
Amount <= 350,000,000 IRR

متوسط:
350,000,000 < Amount <= 3,500,000,000 IRR

عمده:
Amount > 3,500,000,000 IRR
```

خود `350,000,000` جزء است و خود `3,500,000,000` متوسط است.

---

# 11. Expert Fee — حق‌الزحمه کارشناسان

## FEE-001 — Scope

حق‌الزحمه زیرمجموعه فرآیند کارشناسی است، نه یک ماژول مالی جامع.

## FEE-002 — Relation

هر Appraisal حداکثر یک رکورد حق‌الزحمه جاری مربوط به همان کارشناس/فضا دارد.

## FEE-003 — Manual amount

مبلغ حق‌الزحمه دستی ثبت می‌شود.

هیچ فرمول خودکار بین Appraisal Amount و Expert Fee وجود ندارد.

## FEE-004 — Workflow

```text
کارشناسی ثبت‌شده
→ ثبت مبلغ حق‌الزحمه
→ آماده ارسال
→ ارسال به مالی
→ در دست اقدام
→ پرداخت‌شده
→ مختومه
```

و Statusهای استثنایی:

- نیازمند اصلاح؛
- متوقف؛
- لغو شده.

## FEE-005 — Send to finance

برای ارسال به مالی:

- تاریخ ارسال؛
- شماره نامه/گردش؛
- تاریخ نامه/گردش

ثبت می‌شود.

مکاتبه عمومی خارج از SAMA است؛ SAMA فقط Metadata فرآیند را نگه می‌دارد.

## FEE-006 — Batch

ارسال گروهی با Batch پشتیبانی می‌شود.

یک Fee Record هم‌زمان عضو بیش از یک Batch فعال نیست.

## FEE-007 — Payment

پرداخت فقط:

```text
Full
One-time
```

است.

Partial/Staged Payment وجود ندارد.

## FEE-008 — Paid condition

`PAID` فقط وقتی معتبر است که PaidAmount با ExpertFeeAmount برابر باشد و اطلاعات پرداخت تکمیل شده باشد.

## FEE-009 — No general finance

خارج از Scope:

- حسابداری عمومی؛
- دفتر کل؛
- خزانه؛
- مطالبات بهره‌بردار؛
- وصول اجاره؛
- بدهکار/بستانکار عمومی.

---

# 12. Commission — کمیسیون معاملات

## COM-001 — Reference vs Operational

```text
CommissionMember = Reference Data
CommissionSession/Case/Decision = Operational Data
```

## COM-002 — Session snapshot

اعضای هر جلسه Snapshot می‌شوند؛ تغییر اعضای مرجع نباید تاریخچه جلسه گذشته را بازنویسی کند.

## COM-003 — Session structure

```text
CommissionSession
→ CommissionCase
→ CommissionDecision
→ FollowUp
```

## COM-004 — Cross-domain links

Case می‌تواند به:

- Space؛
- Contract؛
- Beneficiary؛
- AuctionPeriod

مرتبط شود.

## COM-005 — Decision validity

تصمیم کمیسیون فقط با مرجع و ثبت رسمی معتبر است.

## COM-006 — Follow-up

تصمیم می‌تواند:

- مسئول پیگیری؛
- وضعیت اجرا؛
- تاریخچه پیگیری

داشته باشد.

## COM-007 — Minutes

صورتجلسه از داده ثبت‌شده جلسه تولید می‌شود.

ترتیب امضا برای هر جلسه تاریخی حفظ می‌شود.

## COM-008 — No physical delete

Session/Case/Decision حذف فیزیکی نمی‌شوند.

---

# 13. Utilities & Consumption — انشعابات و مصرف

## UTL-001 — Domain مستقل

انشعابات/مصرف Domain مستقل است.

ParentProperty فقط Summary وجود/نوع انشعاب را نشان می‌دهد.

CommercialSpace نیز Summary/Link نمایش می‌دهد.

## UTL-002 — Subsystems

حداقل:

- Electricity؛
- Water؛
- Gas.

## UTL-003 — Electricity allocation

برای برق، Bill می‌تواند میان:

```text
Beneficiary Total Share
Organization Share
```

تقسیم شود.

هر دو قابل ویرایش‌اند.

## UTL-004 — Total percentage

```text
Beneficiary Total Share + Organization Share = 100%
```

## UTL-005 — Space allocation

سهم فضاهای مشمول می‌تواند بر اساس:

- Measurement/Submeter معتبر؛
- Equipment data معتبر؛
- مدل مصوب تخصیص؛

محاسبه شود.

## UTL-006 — Override

Manual Override برای سهم هر Space مجاز است، اما:

- علت؛
- User؛
- Timestamp؛
- Audit

لازم دارد.

## UTL-007 — Allocation integrity

```text
Σ Final Space Shares = Beneficiary Total Share
```

و:

```text
Σ Space Payable Amounts + Organization Amount = Bill Amount
```

## UTL-008 — Snapshot

محاسبه نهایی دوره Snapshot می‌شود.

تغییر Rule آینده نباید نتیجه Finalized گذشته را بازنویسی کند.

---

# 14. Auction — اصول قلب سامانه

## AUC-001 — Deterministic Engine

Eligibility مزایده با Rule Engine/Decision Table قطعی انجام می‌شود.

Generative AI حق تعیین Candidate ندارد.

## AUC-002 — Three concepts

این سه مفهوم مستقل‌اند:

```text
Candidate
Selected for AuctionPeriod
Ready for Auction
```

## AUC-003 — Engine outcomes

حداقل:

```text
CANDIDATE
NOT_CANDIDATE
REVIEW_REQUIRED
```

Readiness جداگانه:

```text
READY
ACTION_REQUIRED
REVIEW_REQUIRED
```

## AUC-004 — Fail-safe

داده ناقص/متناقض نباید بی‌صدا `NOT_CANDIDATE` شود.

در موارد غیرقابل تصمیم:

```text
REVIEW_REQUIRED
```

## AUC-005 — Eligibility domain

فقط `CommercialSpace` فعال وارد موتور خودکار می‌شود.

Out-of-Cycle به‌طور خودکار Candidate نمی‌شود.

ParentProperty در Eligibility عملیاتی اثر ندارد.

---

# 15. Auction — مسیر Current Contract

## AUC-010 — Time window

Rule جاری:

```text
1 <= RemainingDays <= 90
```

روز 1 و 90 داخل‌اند.

## AUC-011 — Day 0

در روز پایان:

- Contract همان روز Current است؛
- RemainingDays = 0؛
- Trigger جدید 1..90 ایجاد نمی‌شود.

از روز بعد، Space از مسیر No Current Contract بررسی می‌شود.

## AUC-012 — Configurable

1..90 Hard-code نیست و در Rule Registry Versioned نگهداری می‌شود.

## AUC-013 — Long-term

Duration کل Contract در Eligibility اثر بازدارنده ندارد.

قرارداد 1 ساله، 3 ساله، 5 ساله و بیشتر اگر وارد 1..90 شود یکسان بررسی می‌شود.

---

# 16. Auction — مسیر No Current Contract

## AUC-020

No Current Contract مانع Eligibility نیست.

مسیر:

```text
Active Space
→ No Current Contract
→ Latest Valid Appraisal
→ Transaction Level
→ Other Rules
```

## AUC-021 — No beneficiary

No Beneficiary مانع Eligibility نیست.

## AUC-022 — Missing/expired appraisal

اگر No Current Contract و Appraisal معتبر وجود نداشته باشد:

```text
REVIEW_REQUIRED / ACTION_REQUIRED
```

نه Silent Exclusion.

---

# 17. Auction — Level & Appraisal

## AUC-030 — Auto levels

Auto Candidate levels:

```text
متوسط
عمده
```

جزء Auto Candidate نیست مگر Rule/Override رسمی.

## AUC-031 — Current contract amount

برای Current Contract، Contract Amount مبنای Level است.

## AUC-032 — No contract amount

بدون Current Contract، Latest Valid Appraisal Amount مبناست.

## AUC-033 — Appraisal readiness

برای برگزاری واقعی Auction، Appraisal باید در Planned Auction Date معتبر باشد.

Valid Today ولی Expired on Auction Date → `ACTION_REQUIRED`.

## AUC-034 — Candidate with expired appraisal

Space دارای Current Contract می‌تواند:

```text
CANDIDATE
+
ACTION_REQUIRED: NEW_APPRAISAL
```

باشد.

Candidate و Readiness یکی نیستند.

---

# 18. Auction — Sticky Candidate

## AUC-040

اگر Space در زمان معتبر Rule به‌درستی `CANDIDATE` شد، فقط به‌علت گذر زمان و رسیدن به Day 0/Expiry از Candidate حذف نمی‌شود.

## AUC-041 — Resolve Candidate

Candidate فقط با مسیر رسمی تعیین تکلیف می‌شود؛ از جمله:

- انتخاب/رسیدگی رسمی؛
- Manual Exclusion معتبر؛
- خروج Space از Lifecycle فعال؛
- Correction داده‌ای که ثابت کند Candidate اولیه ناشی از داده اشتباه بوده؛
- Rule رسمی مصوب.

---

# 19. Auction — دستورات و Override

## AUC-050 — Commission/Manager parity

دستور معتبر کمیسیون و مدیر هر دو معتبر و هم‌ترازند.

هیچ Priority مخفی وجود ندارد.

## AUC-051 — Conflict

اگر درباره همان Space/موضوع/بازه، نتیجه متعارض دهند:

```text
CONFLICTING_AUTHORIZED_INSTRUCTIONS
→ REVIEW_REQUIRED
```

سیستم حق انتخاب یکی را ندارد.

## AUC-052 — Manual include/exclude

Manual Include/Exclude مجاز است، اما باید:

- Permission؛
- جهت اثر؛
- دلیل؛
- مرجع؛
- تاریخ اثر؛
- User؛
- Audit

داشته باشد.

Manual Include، Readiness را دور نمی‌زند.

---

# 20. Auction — AuctionPeriod & Lot

## AUC-060 — Official selection

فهرست رسمی دوره مستقیماً از Candidate Engine بدون تأیید ساخته نمی‌شود.

```text
Candidate Suggestions
→ Authorized User Selection
→ AuctionPeriod / AuctionLot
```

## AUC-061 — Lot identity

هر AuctionLot به یک SpaceCode مستقل مربوط است.

## AUC-062 — Open period duplication

یک Space نباید هم‌زمان در چند AuctionPeriod باز قرار گیرد مگر Exception رسمی.

## AUC-063 — Previous no-result

Auction بدون نتیجه پس از بسته/نهایی‌شدن دوره قبلی می‌تواند مجدداً برگزار شود.

## AUC-064 — Snapshot

با ورود رسمی Space به دوره، داده‌های مؤثر، RuleVersion و مبانی تصمیم Snapshot می‌شوند.

---

# 21. Auction — پیشنهادها و جلسه بازگشایی

## AUC-070 — Participant

Participant از Beneficiary مستقل است.

در صورت ایجاد Contract بعدی می‌توان ارتباط لازم را ایجاد کرد.

## AUC-071 — SAMA role

SAMA در دریافت/بازگشایی:

- فرم و سند آماده می‌کند؛
- Receipt را ثبت می‌کند؛
- اطلاعات جلسه را ثبت می‌کند؛
- نتیجه اعلام‌شده توسط مرجع مجاز را ثبت می‌کند.

SAMA:

- Eligibility حقوقی/فنی Participant را مستقلاً قضاوت نمی‌کند؛
- برنده را خودش محاسبه/انتخاب نمی‌کند.

## AUC-072 — Envelope logic

اگر بازنشدن پاکت یا ترتیب پاکت‌ها وابسته به تصمیم جلسه/کمیسیون باشد، سامانه فقط تصمیم ثبت‌شده مرجع مجاز را اجرا/ثبت می‌کند.

## AUC-073 — Declared result

Result = نتیجه اعلام‌شده توسط اعضای مجاز جلسه.

Correction نتیجه نهایی:

- دلیل اجباری؛
- مرجع اجباری؛
- User؛
- Audit؛
- نسخه قبلی محفوظ.

---

# 22. Auction Documents & Golden Master

## DOC-001 — Highlight-only autofill

فقط فیلدهایی که در Golden Master برای تکمیل خودکار تأیید شده‌اند توسط SAMA پر می‌شوند.

Blank غیرمجاز نباید صرفاً چون SAMA داده را می‌داند پر شود.

## DOC-002 — Static text lock

متن ثابت حقوقی/رسمی Runtime تغییر نمی‌کند.

ویرایش ظاهری مجاز است؛ تغییر معنی ممنوع.

## DOC-003 — Page order

Page order قفل است.

Atomic one-page documents باید دقیقاً یک صفحه بمانند.

## DOC-004 — Deposit

مبلغ سپرده هر Lot مستقل است.

هیچ فرمول خودکار پیش‌فرضی برای آن فرض نمی‌شود.

## DOC-005 — Official logo

فقط Asset رسمی لوگوی سازمان استفاده می‌شود.

متن زیر لوگو نباید با تایپ مجدد بازسازی شود.

## DOC-006 — Print

نسخه چاپی:

- سیاه‌وسفید امن؛
- Low toner؛
- خوانا؛
- بدون وابستگی به رنگ برای تشخیص؛
- مناسب A4/A3 حسب سند.

## DOC-007 — Template versioning

هر Template:

- Version؛
- Effective date؛
- Hash

دارد.

## DOC-008 — Generated instance

هر Document Instance باید قابل اتصال به:

- Template Version؛
- Data Snapshot؛
- Generator User/Time؛
- Hash/Metadata

باشد.

## DOC-009 — PPT image placeholder

عکس فضای تجاری در Database وجود ندارد.

PowerPoint می‌تواند:

```text
Manual Optional Image Placeholder
```

داشته باشد.

کاربر پس از تولید فایل، عکس را دستی قرار می‌دهد.

خالی بودن Placeholder مانع تولید فایل نیست.

## DOC-010 — PDF authority

PDF نسخه چاپی مرجع است؛ DOCX فقط در موارد کنترل‌شده و مصوب.

---

# 23. Report Engine

## REP-001 — Single dataset

Screen، KPI، Chart، Drill-down، Excel و PDF باید از یک Query/Dataset رسمی استفاده کنند.

عدد Summary نباید از منطق جداگانه نسبت به Drill-down محاسبه شود.

## REP-002 — Controlled Builder

Report Builder اجازه:

- انتخاب Subject؛
- Column؛
- Order؛
- Filter؛
- Sort؛
- Group؛
- Aggregate؛
- Chart؛
- Output؛

می‌دهد.

Free SQL/Join/Formula scripting برای User عادی وجود ندارد.

## REP-003 — Custom blank column

`CUSTOM_BLANK_COLUMN` مجاز است.

این ستون:

- فقط Layout/Output است؛
- Data Field نیست؛
- در Database ذخیره نمی‌شود؛
- Shadow Data ایجاد نمی‌کند.

## REP-004 — Saved Report

Saved Report تعریف Query/Layout را ذخیره می‌کند، نه Dataset.

## REP-005 — Snapshot Report

Snapshot Report:

- Dataset؛
- Query؛
- Filter؛
- Columns؛
- Hash؛
- GeneratedBy/At

را Freeze می‌کند.

## REP-006 — Current vs Historical

Current State و Historical Snapshot باید صریحاً از هم جدا باشند.

Past state از Current state بازسازی تخمینی نمی‌شود.

## REP-007 — Organization filters

فیلتر سلسله‌مراتبی:

```text
Organization
→ Region
→ Center
```

سه Mode رسمی Region/Center:

```text
ALL_CENTERS_IN_SELECTED_REGIONS
ONLY_SELECTED_CENTERS
SELECTED_REGIONS_PLUS_EXTRA_CENTERS
```

## REP-008 — Filter logic

داخل یک Dimension:

```text
OR
```

بین Dimensionها:

```text
AND
```

با رعایت Region/Center Mode.

## REP-009 — Appraisal columns on space list

حداقل:

- Latest Appraisal؛
- Previous Appraisal 1؛
- Previous Appraisal 2

بدون بازکردن پرونده قابل نمایش است.

هر Slot می‌تواند Date/Amount/Expert/Historical Level را نشان دهد.

Historical Level با Rule امروز Recalculate نمی‌شود.

## REP-010 — Full history

برای تاریخچه طولانی از Long-form/Drill-down استفاده می‌شود؛ ستون نامحدود ممنوع.

## REP-011 — Aggregates

فقط جایی که معنا دارد:

```text
COUNT
SUM
AVG
MIN
MAX
```

## REP-012 — Export identity

Excel/PDF باید دقیقاً Dataset فیلتر/جست‌وجو/Sortشده جاری را منعکس کند.

---

# 24. SpaceCode Scoped Search

## SEARCH-001

کلید جست‌وجوی دقیق:

```text
CommercialSpace.space_code
```

No fuzzy guessing.

## SEARCH-002 — Domain selector

کاربر یک یا چند Domain انتخاب می‌کند:

- مشخصات؛
- قرارداد؛
- بهره‌بردار؛
- کارشناسی؛
- کارشناسان مرتبط؛
- مزایده؛
- کمیسیون؛
- حق‌الزحمه؛
- انشعابات؛
- اسناد؛
- Audit؛
- همه موارد.

## SEARCH-003 — Two modes

```text
Focused Search
Full 360 Dossier
```

## SEARCH-004 — Permission

Baseline فعلی پنج کاربر عملیاتی Permission برابر دارند؛ با این حال Query باید از Policy Server-side عبور کند تا تغییر Policy آینده امن باشد.

## SEARCH-005 — Empty distinction

این دو متفاوت‌اند:

```text
SpaceCode Not Found
SpaceCode Found + No Data in Selected Domain
```

---

# 25. Dashboard

## DASH-001 — Report Engine presentation

Dashboard منطق موازی ایجاد نمی‌کند.

تمام KPI/Chart از Report Engine رسمی می‌آیند.

## DASH-002 — Drill-down required

KPI بدون Drill-down واقعی ممنوع است.

## DASH-003 — First View

Above-the-fold:

```text
6–8 KPI maximum
2–3 meaningful charts maximum
```

KPI Catalog می‌تواند بزرگ‌تر باشد.

## DASH-004 — Remaining KPI

KPIهای دیگر:

- پایین‌تر صفحه؛
- Domain Section؛
- نمایش بیشتر؛
- Drill-down؛
- Saved View.

## DASH-005 — Action Center

اولویت:

- قرارداد نزدیک پایان؛
- Appraisal منقضی/نیازمند اقدام؛
- Candidate Action Required؛
- Review Required؛
- پرونده ناقص؛
- Expert Fee در دست اقدام؛
- Data Quality؛
- تصمیم/پیگیری مدیر یا کمیسیون.

## DASH-006 — Equal users

پنج کاربر عملیاتی Dashboard Engine و KPI Catalog یکسان دارند.

Saved View شخصی مجاز است؛ Role-based hiding در Baseline فعلی وجود ندارد.

## DASH-007 — No auto interpretation

Dashboard تفسیر حقوقی، تعیین برنده یا تصمیم مدیریتی خودکار تولید نمی‌کند.

## DASH-008 — Zero/Error/Empty

این وضعیت‌ها جدا هستند:

- Zero data؛
- No result؛
- Loading؛
- Error؛
- Read-only؛
- Unauthorized.

---

# 26. Data Quality & Completeness

## DQ-001 — Incomplete ≠ deleted

پرونده ناقص حذف نمی‌شود و از دید کنترل کیفیت پنهان نمی‌شود.

## DQ-002 — Context-aware completeness

Completeness وابسته به Context است.

مثلاً نیازهای مزایده می‌تواند با پرونده عادی فرق داشته باشد.

## DQ-003 — Contradictions

نمونه ناسازگاری‌های مهم:

- دو Current Contract هم‌پوشان؛
- دو Current Appraisal؛
- تاریخ‌های نامعتبر؛
- مبلغ نامعتبر؛
- Rule سالانه ثبت‌نشده؛
- دستورهای معتبر متعارض.

## DQ-004 — Re-evaluation

پس از اصلاح داده، Rule/Completeness دوباره ارزیابی می‌شود.

## DQ-005 — No silent exclusion

به‌ویژه در Auction، نقص داده نباید رکورد را بی‌صدا از Candidate path حذف کند.

---

# 27. Audit & Snapshot

## AUD-001 — Append history

History مهم حذف/overwrite نمی‌شود.

## AUD-002 — Sensitive actions

حداقل این موارد Audit کامل دارند:

- Lifecycle Space؛
- Contract edit/cancel؛
- Appraisal correction/current change؛
- Expert fee؛
- Commission decision؛
- Auction rule/override/result؛
- User/password reset؛
- Final document generation؛
- Utility override/finalization.

## AUD-003 — Snapshot immutability

Snapshot تاریخی با تغییر Rule یا Data جاری بازنویسی نمی‌شود.

---

# 28. Documents, notes, correspondence

## GEN-001 — Files optional unless specifically required

در اکثر Domainها File attachment به‌خودی‌خود شرط وجود رکورد نیست، مگر Rule رسمی همان فرآیند خلافش را بگوید.

## GEN-002 — Notes

یادداشت جدید:

- User؛
- Date/time؛
- Subject در صورت نیاز؛
- Text

دارد و یادداشت قبلی overwrite نمی‌شود.

## GEN-003 — General correspondence

SAMA سامانه اتوماسیون مکاتبات عمومی نیست.

Metadata لازم برای Process Tracking ثبت می‌شود؛ متن/گردش سازمانی عمومی خارج از Scope است مگر در Domain مشخص مصوب.

---

# 29. UI/UX rules that are already FROZEN

> High-Fidelity Page Review اخیر هنوز خارج از Freeze این Master است؛ اما Design System پایه و Anti-AI rules مصوب هستند.

## UX-001 — Anti-AI red line

هر خروجی شبیه Generic AI/SaaS Template مردود است.

ممنوع:

- Card Soup؛
- Gradient تزئینی؛
- Glow/Neon؛
- Glass در کل Workspace؛
- Radius بسیار بزرگ در همه اجزا؛
- Pill Button everywhere؛
- Hero graphic در صفحه عملیاتی؛
- تصاویر ساختگی؛
- Iconهای نمایشی بی‌کارکرد؛
- Dashboard پر از Donut؛
- متن‌های کلیشه‌ای AI؛
- Whitespace نمایشی به قیمت کارایی.

## UX-002 — Data first

```text
Data > Decoration
Action > Illustration
Structure > Effect
Legibility > Novelty
```

## UX-003 — RTL native

UI از ابتدا RTL طراحی می‌شود، نه اینکه LTR Mirror شود.

## UX-004 — UI font

فونت اصلی UI:

```text
Vazirmatn
```

به‌صورت Local Asset و بدون CDN.

## UX-005 — Numerals

اعداد کاربرمحور UI با ارقام فارسی نمایش داده می‌شوند.

Technical IDs/Hashes/File names لاتین می‌مانند.

## UX-006 — Alignment

- متن فارسی → راست؛
- مبلغ/عدد نمایشی → راست؛
- تاریخ شمسی → راست؛
- Technical/Reference ID → LTR در Field خودش.

## UX-007 — Tables

Table عنصر اصلی صفحات داده‌محور است.

- Sticky Header؛
- Search؛
- Filter؛
- Sort؛
- Pagination؛
- Column Visibility؛
- Controlled horizontal scroll؛
- Sticky identity column در صورت نیاز.

## UX-008 — Forms

فرم‌های اصلی Full Page/Section-based هستند.

Modal برای فرم بزرگ ممنوع.

اطلاعات مالی Section مستقل دارد.

## UX-009 — Responsive target

Desktop/LAN اولویت.

1366×768 باید First-class باشد.

## UX-010 — Print separate

Screen UI مستقیماً Print نمی‌شود.

Print Template مستقل و رسمی دارد.

---

# 30. Color identity

پالت‌های دقیق در MD «نظام رنگ، پالت ماژول‌ها و هویت بصری» مرجع هستند.

قاعده:

```text
Shared Design System
+ Module Color Identity
+ Fixed Semantic Colors
+ Shared Neutral System
```

رنگ Module معنای Status را جایگزین نمی‌کند.

---

# 31. Global print/export

## PRINT-001

خروجی رسمی:

- RTL؛
- لوگوی رسمی؛
- عنوان؛
- تاریخ؛
- User؛
- Scope/Filter؛
- Count؛
- Border سلولی؛
- Repeat Header؛
- Page number؛
- Thousand separator.

## PRINT-002

برای گزارش عریض:

- Landscape؛
- A3 در صورت نیاز؛
- عدم Shrink تا حد ناخوانا.

## PRINT-003

Excel:

- RTL؛
- Numeric واقعی برای مبلغ؛
- Filter؛
- Freeze header؛
- بدون Merge غیرضروری.

---

# 32. Runtime / LAN constraints

## RUN-001

SAMA باید در شبکه داخلی سازمان و از Browser اجرا شود.

Target:

```text
Chrome
Edge
LAN
No Client Installation
```

## RUN-002

Navigation یا Function اصلی نباید نیازمند نصب Client روی PC سازمان باشد.

## RUN-003

Assetهای لازم برای Runtime باید Local باشند؛ وابستگی ضروری به CDN/Internet ممنوع است.

---

# 33. Out of scope

در Baseline فعلی خارج از Scope:

- ParentProperty appraisal/auction؛
- General accounting/GL/Treasury؛
- General receivables/collections؛
- Complex RBAC؛
- MFA/OTP/SSO؛
- Automatic legal eligibility judgment of bidders؛
- Automatic winner selection؛
- CommercialSpace photo/gallery؛
- Automatic legacy data migration؛
- General correspondence automation؛
- Contract extension entity/workflow؛
- AI-generated eligibility rules.

---

# 34. Cross-domain invariants

## INV-001

`SpaceCode` هویت اصلی CommercialSpace است و تغییر نمی‌کند.

## INV-002

هر Contract دقیقاً یک Space + یک Beneficiary دارد.

## INV-003

یک Space بیش از یک Current Contract هم‌پوشان ندارد.

## INV-004

هر Appraisal دقیقاً یک Space + یک Expert دارد.

## INV-005

در هر لحظه یک Appraisal Current/Reference برای Space وجود دارد.

## INV-006

ParentProperty رابطه عملیاتی اجباری با Space ندارد.

## INV-007

No Beneficiary و No Contract دو مفهوم متفاوت‌اند.

## INV-008

Contract Extension وجود ندارد؛ Contract جدید ثبت می‌شود.

## INV-009

Auction Candidate ≠ Auction Selected ≠ Auction Ready.

## INV-010

Current State ≠ Historical Snapshot.

## INV-011

Official KPI Count = Drill-down Dataset Count برای همان Query/Scope/AsOf.

## INV-012

Business rule change نباید History گذشته را بازنویسی کند.

---

# 35. Acceptance gates قبل از Coding

هیچ Implementation نهایی نباید قبل از این موارد شروع/تکمیل تلقی شود:

## QA-001 — Rule consistency

- Conflict باز Critical/High = 0
- Ruleهای مرزی Auction تست‌پذیر
- No Guess رعایت شده

## QA-002 — Data model invariants

- SpaceCode unique/immutable
- Contract overlap protection
- Single current appraisal
- Referential integrity
- No physical delete on core records

## QA-003 — Auction tests

حداقل:

- RemainingDays: 91 / 90 / 1 / 0 / expired
- Long-term >365
- Current contract vs no contract
- Medium/major boundaries
- Appraisal validity edge
- Missing appraisal
- Conflicting directives
- Sticky candidate
- Out-of-cycle exclusion
- Duplicate open period
- No silent exclusion

## QA-004 — Document tests

- Golden Master
- Static text fingerprint
- Placeholder gate
- Overflow gate
- Page count/order
- PDF visual regression
- B/W print test
- official logo
- no unauthorized autofill

## QA-005 — Report consistency

```text
KPI
= Drill-down
= Search/Report
```

برای Query/Scope واحد.

## QA-006 — UI gate

- Anti-AI checklist pass
- 1366×768 pass
- RTL pass
- Persian numerals pass
- no clipping
- meaningful empty/error states

## QA-007 — LAN gate

- Chrome/Edge
- no install
- no required internet
- named-user audit
- admin password reset path

---

# 36. Definition of Done کسب‌وکاری

یک Feature «تمام‌شده» نیست مگر:

1. Rule منبع مشخص داشته باشد.
2. Data ownership مشخص باشد.
3. State/Status مشخص باشد.
4. Validation مشخص باشد.
5. Empty/Error/Review behavior مشخص باشد.
6. Audit behavior مشخص باشد.
7. Search/Filter در صورت نیاز مشخص باشد.
8. Report/Export behavior در صورت نیاز مشخص باشد.
9. Permission policy رعایت شود.
10. Test پذیرش داشته باشد.
11. UI از Design System پیروی کند.
12. Business meaning را تغییر نداده باشد.

---

# 37. قانون مخصوص AI/Codex

این سند برای مرحله بعد به‌عنوان Guardrail استفاده می‌شود.

هر Agent:

```text
IMPLEMENTER, NOT PRODUCT OWNER
```

است.

Agent حق ندارد:

- Rule بسازد؛
- Rule حذف کند؛
- Missing value حدس بزند؛
- تصمیم Business بگیرد؛
- UI identity را خودسرانه عوض کند؛
- Data Sample را Production فرض کند؛
- Prototype قدیمی را Authority بداند؛
- اسناد رسمی را بازنویسی کند؛
- نتیجه Auction را استنتاج کند.

اگر ابهام دید:

```text
STOP
→ cite document/section
→ report ambiguity
→ wait for approved decision
```

---

# 38. Source map

جزئیات هر حوزه در اسناد زیر باقی می‌ماند:

- `MD املاک مادر — FINAL FROZEN.md`
- `MD فضاهای تجاری — FINAL FROZEN.md`
- `MD بهره‌برداران — FINAL FROZEN.md`
- `MD قراردادها — FINAL FROZEN.md`
- `MD کارشناسی — FINAL FROZEN.md`
- `MD حق‌الزحمه کارشناسان — FINAL FROZEN.md`
- `MD کمیسیون معاملات — FINAL FROZEN.md`
- `MD انشعابات و مصرف — FINAL FROZEN.md`
- `MD مزایده — FINAL FROZEN.md`
- `MD اسناد رسمی و Golden Master مزایده — FINAL FROZEN.md`
- `Golden_Master_Field_Registry_فضای_تجاری.md`
- `MD موتور گزارش‌گیری و تحلیل مدیریتی — FINAL FROZEN v2.md`
- `MD داشبورد مدیریتی نهایی — FINAL FROZEN.md`
- `MD معماری اطلاعات، Sitemap، Navigation و کاربران — FINAL FROZEN.md`
- `MD نظام رنگ، پالت ماژول‌ها و هویت بصری — FINAL FROZEN.md`
- `MD سیستم طراحی اجرایی و استاندارد UI-UX — FINAL FROZEN.md`

---

# 39. وضعیت نهایی

```text
SAMA MASTER LOGIC = FINAL FROZEN
HIGH-FIDELITY UI REVIEW = NOT INCLUDED YET
CODE IMPLEMENTATION = NOT STARTED BY THIS DOCUMENT
```

از این نقطه، تغییر Business Logic فقط با Change Request مجاز است.

---

**پایان سند — SAMA MASTER RULEBOOK — FINAL FROZEN**
