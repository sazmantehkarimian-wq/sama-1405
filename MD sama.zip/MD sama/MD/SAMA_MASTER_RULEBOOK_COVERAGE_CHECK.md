# SAMA MASTER RULEBOOK — COVERAGE CHECK

**Status:** PASS

این فایل فقط برای کنترل داخلی بسته است و Rule جدید ایجاد نمی‌کند.

## Domain coverage

| Domain | Master section | Detailed FINAL FROZEN source |
|---|---|---|
| Governance / No Guess / Change Control | 0 | Authority Index + all domain change rules |
| Zero-data | 1 | ParentProperty v1.2 + IA Zero-data |
| Users/Auth | 3 | IA / Users |
| Navigation | 4 | IA / Sitemap |
| ParentProperty | 5 | MD املاک مادر |
| CommercialSpace | 6 | MD فضاهای تجاری |
| Beneficiary | 7 | MD بهره‌برداران |
| Contract | 8 | MD قراردادها |
| Expert/Appraisal | 9 | MD کارشناسی |
| Transaction Level | 10 | Contract/Appraisal/Auction |
| Expert Fee | 11 | MD حق‌الزحمه |
| Commission | 12 | MD کمیسیون |
| Utilities | 13 | MD انشعابات |
| Auction | 14–21 | MD مزایده |
| Official Documents | 22 | Golden Master docs + Field Registry |
| Report Engine | 23 | Report Engine v2 |
| Scoped Search | 24 | Report Engine v2 |
| Dashboard | 25 | Dashboard |
| Data Quality | 26 | Domain MDs |
| Audit/Snapshot | 27 | Domain MDs |
| General documents/notes | 28 | Domain MDs |
| UI/UX frozen baseline | 29–30 | Color + Design System |
| Print/export | 31 | Report/Print standards |
| LAN runtime constraints | 32 | IA + Design System |
| Out of Scope | 33 | Consolidated |
| Cross-domain invariants | 34 | Consolidated |
| Acceptance gates | 35–36 | Consolidated |
| AI/Codex guardrail | 37 | Consolidated |

## Conflict corrections included

- ParentProperty legacy migration language → replaced with Zero-data / Manual Entry.
- ParentProperty fixed range implying preloaded 225 records → removed; code shown only as format example.
- Dashboard role-specific variants → removed; five named operational users have equal access.
- CommercialSpace photo/gallery → prohibited.
- PowerPoint image → manual optional placeholder only.
- UI font → Vazirmatn local.
- Persian numeral/alignment rule → explicit.
- Dashboard KPI catalog → separated from first-view cap.

**Coverage result:** `PASS`
