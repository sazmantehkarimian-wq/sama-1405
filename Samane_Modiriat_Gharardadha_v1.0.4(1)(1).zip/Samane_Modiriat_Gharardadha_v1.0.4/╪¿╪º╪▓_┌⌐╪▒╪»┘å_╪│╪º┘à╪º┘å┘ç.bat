@echo off
chcp 65001 >nul
set "HERE=%~dp0"
start "" "%HERE%index.html"
exit /b 0
