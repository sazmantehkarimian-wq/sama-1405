بسته نصب UAT نسخه 4.0.0-uat.2
INSTALL_UAT.bat را اجرا کنید. نصب‌کننده سه بخش Runtime مرجع را از Repository رسمی دریافت،
SHA-256 هر بخش و فایل نهایی را بررسی، Runtime را Extract و داده و تنظیمات UAT را Overlay می‌کند.
پس از نصب SAMA_RUNTIME\START_SERVER.bat را اجرا کنید.
نشانی شبکه: http://SERVER-IP:8765
