﻿@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title SAMA Enterprise LAN v4.0.0-uat.2

if not exist "logs" mkdir "logs"
if not exist "backups" mkdir "backups"
if not exist "media" mkdir "media"

>"logs\startup_launcher.log" echo ============================================================
>>"logs\startup_launcher.log" echo SAMA Enterprise LAN v4.0.0-uat.2 - LONG TERM OVER 365 DAYS - MASTER 1405-05-11
>>"logs\startup_launcher.log" echo Started: %DATE% %TIME%
>>"logs\startup_launcher.log" echo Folder: %CD%
>>"logs\startup_launcher.log" echo ============================================================

echo ============================================================
echo SAMA Enterprise LAN v4.0.0-uat.2 - SAFE START
echo ============================================================

if not exist "data\database.sqlite3" goto :missing_database
if not exist "data\source\SAMA_MASTER_1405-05-11.xlsx" goto :missing_master
if not exist "app\SamaServerV350.exe" goto :missing_launcher
if not exist "app\server_boot.py" goto :missing_boot
if not exist "app\_internal\python312.dll" goto :missing_python

set "SAMANE_AMLAK_DATA_DIR=%CD%\data"
set "SAMANE_AMLAK_MEDIA_DIR=%CD%\media"
set "SAMANE_AMLAK_LOG_DIR=%CD%\logs"
set "SAMANE_AMLAK_ALLOWED_HOSTS=*"
set "SAMANE_AMLAK_PORT=8765"
set "DJANGO_DEBUG=0"
set "LAN_PRODUCTION=1"
set "SAMA_MODE=server"

rem Stop only known old SAMA processes. Port checks are handled by the server.
taskkill /F /IM SamaServerV350.exe >nul 2>&1
taskkill /F /IM SamaneAmlakServer.exe >nul 2>&1

>"logs\active_package_version.txt" echo SAMA_4.0.0-UAT.2_PORT_8765

echo Starting server...
echo Local address: http://127.0.0.1:8765/
echo Keep this window open while users are working.
echo Detailed log: logs\startup_runtime.log
echo ============================================================

"app\SamaServerV350.exe"
set "RC=%ERRORLEVEL%"

if "%RC%"=="0" exit /b 0

echo.
echo [ERROR] The server stopped. Error code: %RC%
echo The complete error is saved in logs\startup_runtime.log
>>"logs\startup_launcher.log" echo Server exit code: %RC%
pause
exit /b %RC%

:missing_database
echo [ERROR] data\database.sqlite3 was not found.
>>"logs\startup_launcher.log" echo Missing: data\database.sqlite3
pause
exit /b 11

:missing_launcher
echo [ERROR] app\SamaServerV350.exe was not found.
>>"logs\startup_launcher.log" echo Missing: app\SamaServerV350.exe
pause
exit /b 12

:missing_master
echo [ERROR] data\source\SAMA_MASTER_1405-05-11.xlsx was not found.
>>"logs\startup_launcher.log" echo Missing: data\source\SAMA_MASTER_1405-05-11.xlsx
pause
exit /b 15

:missing_boot
echo [ERROR] app\server_boot.py was not found.
>>"logs\startup_launcher.log" echo Missing: app\server_boot.py
pause
exit /b 13

:missing_python
echo [ERROR] app\_internal\python312.dll was not found.
>>"logs\startup_launcher.log" echo Missing: app\_internal\python312.dll
pause
exit /b 14
