# -*- coding: utf-8 -*-
"""Reliable runtime launcher for SAMA 4.0.0-uat.2."""
import datetime as _dt
import os
import sqlite3
import sys
import traceback


class _Tee:
    def __init__(self, *streams):
        self.streams = streams

    def write(self, data):
        for stream in self.streams:
            try:
                stream.write(data)
                stream.flush()
            except Exception:
                pass
        return len(data)

    def flush(self):
        for stream in self.streams:
            try:
                stream.flush()
            except Exception:
                pass


def _paths():
    app_dir = os.path.dirname(os.path.abspath(sys.executable))
    package_root = os.path.dirname(app_dir) if os.path.basename(app_dir).lower() == "app" else app_dir
    internal = os.path.join(app_dir, "_internal")
    return package_root, app_dir, internal


def _open_runtime_log(package_root):
    log_dir = os.path.join(package_root, "logs")
    os.makedirs(log_dir, exist_ok=True)
    path = os.path.join(log_dir, "startup_runtime.log")
    return open(path, "a", encoding="utf-8", buffering=1), path


def _check_database(database_path):
    if not os.path.exists(database_path):
        raise FileNotFoundError("Database not found: %s" % database_path)
    with sqlite3.connect(database_path, timeout=30) as con:
        con.execute("PRAGMA foreign_keys=ON")
        con.execute("PRAGMA busy_timeout=30000")
        result = con.execute("PRAGMA integrity_check").fetchone()
        if not result or str(result[0]).lower() != "ok":
            raise RuntimeError("SQLite integrity_check failed: %r" % (result,))


def _verified_backup(database_path, package_root, category="automatic", strict=False):
    try:
        backup_dir = os.path.join(package_root, "backups", category)
        os.makedirs(backup_dir, exist_ok=True)
        stamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        target = os.path.join(backup_dir, "database_%s.sqlite3" % stamp)
        with sqlite3.connect(database_path, timeout=30) as source, sqlite3.connect(target, timeout=30) as destination:
            source.execute("PRAGMA busy_timeout=30000")
            source.backup(destination)
        with sqlite3.connect(target, timeout=30) as check:
            result = check.execute("PRAGMA integrity_check").fetchone()
            if not result or str(result[0]).lower() != "ok":
                raise RuntimeError("Backup integrity_check failed: %r" % (result,))
        files = sorted(
            (os.path.join(backup_dir, name) for name in os.listdir(backup_dir) if name.lower().endswith(".sqlite3")),
            key=os.path.getmtime,
            reverse=True,
        )
        for old in files[30:]:
            try:
                os.remove(old)
            except OSError:
                pass
        print("Verified backup created: %s" % target, flush=True)
        return target
    except Exception as exc:
        print("WARNING: backup could not be created: %s" % exc, flush=True)
        if strict:
            raise
        return None


def _configure_runtime(package_root, internal):
    os.chdir(package_root)
    sys.frozen = True
    sys._MEIPASS = internal
    sys.dont_write_bytecode = True
    if internal not in sys.path:
        sys.path.insert(0, internal)

    data_dir = os.path.join(package_root, "data")
    database_path = os.path.join(data_dir, "database.sqlite3")
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
    os.environ.setdefault("LAN_PRODUCTION", "1")
    os.environ.setdefault("DJANGO_DEBUG", "0")
    os.environ.setdefault("SAMANE_AMLAK_DATA_DIR", data_dir)
    os.environ.setdefault("SAMANE_AMLAK_DB_PATH", database_path)
    os.environ.setdefault("SAMANE_AMLAK_MEDIA_DIR", os.path.join(package_root, "media"))
    os.environ.setdefault("SAMANE_AMLAK_LOG_DIR", os.path.join(package_root, "logs"))
    os.environ.setdefault("SAMANE_AMLAK_ALLOWED_HOSTS", "*")
    return database_path


def main():
    package_root, _app_dir, internal = _paths()
    runtime_log, log_path = _open_runtime_log(package_root)
    original_stdout, original_stderr = sys.stdout, sys.stderr
    sys.stdout = _Tee(original_stdout, runtime_log)
    sys.stderr = _Tee(original_stderr, runtime_log)

    print("\n" + "=" * 68)
    print("SAMA 4.0.0-uat.2 startup: %s" % _dt.datetime.now().isoformat(sep=" ", timespec="seconds"))
    print("Package root: %s" % package_root)
    print("Runtime log: %s" % log_path)
    print("=" * 68, flush=True)

    database_path = _configure_runtime(package_root, internal)
    mode = os.environ.get("SAMA_MODE", "server").strip().lower()
    _check_database(database_path)

    if mode == "backup":
        _verified_backup(database_path, package_root, category="manual", strict=True)
        return 0

    # Startup backup is best-effort. A backup failure is logged but never blocks the application.
    _verified_backup(database_path, package_root, category="automatic", strict=False)

    from django.core.wsgi import get_wsgi_application
    from waitress import serve

    port = int(os.environ.get("SAMANE_AMLAK_PORT", "8765"))
    application = get_wsgi_application()
    print("Database integrity: OK")
    print("Local: http://127.0.0.1:%s/" % port)
    print("LAN:   http://<SERVER-IP>:%s/" % port)
    print("Keep this window open while users are working.")
    print("=" * 68, flush=True)
    serve(application, host="0.0.0.0", port=port, threads=8, channel_timeout=120)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(0)
    except BaseException:
        traceback.print_exc()
        raise
