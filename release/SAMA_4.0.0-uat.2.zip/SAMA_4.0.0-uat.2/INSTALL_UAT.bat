@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALL_UAT.ps1"
if errorlevel 1 pause
