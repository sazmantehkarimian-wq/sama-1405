$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$install = Join-Path $root "SAMA_RUNTIME"
$temp = Join-Path $env:TEMP ("sama-uat-" + [guid]::NewGuid())
New-Item -ItemType Directory -Force -Path $temp | Out-Null
$base = "https://raw.githubusercontent.com/sazmantehkarimian-wq/sama-1405/main/"
$names = @(
 "SAMA_ENTERPRISE_LAN_v3.8.5_LONG_TERM_OVER_365_1405-05-15(1).zip.part001",
 "SAMA_ENTERPRISE_LAN_v3.8.5_LONG_TERM_OVER_365_1405-05-15(1).zip.part002",
 "SAMA_ENTERPRISE_LAN_v3.8.5_LONG_TERM_OVER_365_1405-05-15(1).zip.part003"
)
$expected = @(
 "955c627678b4ec9148c56a18a00d3a378969f04cb0a428794002fed390689878",
 "a85f22bfc9b2a706bd6418a34afd14063a5ec773e16ada63dffc862b4c8b4938",
 "a636f7968790d6be7a18e06d31d361c9beb6fb9bcddafc4a3590f2710e6f488c"
)
$parts = @()
for ($i=0; $i -lt $names.Count; $i++) {
  $part = Join-Path $temp $names[$i]
  Invoke-WebRequest -Uri ($base + [uri]::EscapeDataString($names[$i])) -OutFile $part
  if ((Get-FileHash $part -Algorithm SHA256).Hash.ToLower() -ne $expected[$i]) { throw "SHA-256 mismatch: $($names[$i])" }
  $parts += $part
}
$archive = Join-Path $temp "base.zip"
$out = [System.IO.File]::Create($archive)
foreach ($part in $parts) { $bytes=[System.IO.File]::ReadAllBytes($part); $out.Write($bytes,0,$bytes.Length) }
$out.Close()
if ((Get-FileHash $archive -Algorithm SHA256).Hash.ToLower() -ne "332973817a13c00f11edb066c0729197df83dcb5637f008e96c0dad68cd4082c") { throw "Base archive SHA-256 mismatch" }
Expand-Archive -LiteralPath $archive -DestinationPath $temp -Force
$source = Get-ChildItem $temp -Recurse -Filter START_SERVER.bat | Select-Object -First 1 | ForEach-Object { $_.Directory.FullName }
if (-not $source) { throw "Base package was not found" }
Remove-Item $install -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item $source $install -Recurse
Copy-Item (Join-Path $root "overlay\*") $install -Recurse -Force
Remove-Item $temp -Recurse -Force
Write-Host "SAMA 4.0.0-uat.2 installed and SHA-256 verified."
Write-Host "Run: $install\START_SERVER.bat"
Write-Host "LAN: http://SERVER-IP:8765"
